var EventHubClient = require('azure-event-hubs').Client;

var connStr = '<YOUR_CONNECTION_STRING>';
var eventHub = '<YOUR_EVENT_HUB>'

var client = EventHubClient.fromConnectionString(connStr, eventHub)
client.createSender()
    .then(function (tx) {
        setInterval(function(){
            dev = 'dev' + String(Math.floor((Math.random() * 10) + 1));
            val = String(Math.random());
            console.log(dev + ": " + val);
            tx.on('errorReceived', function (err) { console.log(err); });
            tx.send({ device: dev, reading: val}); 
         }, 1000);
    });
